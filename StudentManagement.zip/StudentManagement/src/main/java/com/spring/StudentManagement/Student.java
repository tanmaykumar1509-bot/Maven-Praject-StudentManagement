package com.spring.StudentManagement;

public class Student {

    private int rollNo;
    private String name;
    private Course course;

    // Constructor Injection
    public Student(int rollNo, String name) {
        this.rollNo = rollNo;
        this.name = name;
    }

    // Setter Injection
    public void setCourse(Course course) {
        this.course = course;
    }

    public void display() {
        System.out.println("Roll Number: " + rollNo);
        System.out.println("Name: " + name);
        course.display();
    }
}